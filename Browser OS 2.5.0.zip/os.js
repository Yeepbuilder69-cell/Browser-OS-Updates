(function(){
'use strict';
const $=s=>document.querySelector(s);
const el=(t,c,h)=>{const e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e};
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

let S={bg:'#1e3a5f',bgImg:'',cursor:'default',cursorImg:'',bootText:'Welcome',pass:'',sound:true,apps:[],hiddenApps:[],iconPos:{},pinned:[],fs:{id:'root',type:'dir',name:'Root',kids:[]}};
let z=10,wins={},cursorStyle=null;

function load(cb){chrome.storage.local.get('bos',r=>{if(r.bos)S=Object.assign(S,r.bos);migrate();chrome.storage.local.set({bos:S});cb()})}
let lastDeskSig='';
function save(){chrome.storage.local.set({bos:S});if(started&&typeof deskSig==='function'&&deskSig()!==lastDeskSig)renderIcons()}
const uid=()=>Math.random().toString(36).slice(2,10);

/* ---------- sound effects (generated in code, no audio files) ---------- */
let actx=null;
function tone(freq,start,dur,type,vol){
  if(!S.sound)return;
  try{
    if(!actx)actx=new (window.AudioContext||window.webkitAudioContext)();
    if(actx.state==='suspended')actx.resume();
    const o=actx.createOscillator(),g=actx.createGain();
    o.type=type||'sine';o.frequency.value=freq;
    const t0=actx.currentTime+start;
    g.gain.setValueAtTime(0.0001,t0);
    g.gain.exponentialRampToValueAtTime(vol||0.15,t0+0.01);
    g.gain.exponentialRampToValueAtTime(0.0001,t0+dur);
    o.connect(g);g.connect(actx.destination);
    o.start(t0);o.stop(t0+dur+0.02);
  }catch(e){}
}
const sfx={
  click:()=>tone(900,0,0.05,'square',0.05),
  open:()=>{tone(500,0,0.08,'sine',0.12);tone(750,0.07,0.12,'sine',0.12)},
  close:()=>{tone(700,0,0.08,'sine',0.12);tone(450,0.07,0.12,'sine',0.12)},
  chime:()=>{tone(523,0,0.35,'sine',0.15);tone(659,0.18,0.35,'sine',0.15);tone(784,0.36,0.6,'sine',0.15)},
  error:()=>tone(200,0,0.2,'sawtooth',0.1),
  notify:()=>{tone(660,0,.09,'sine',.09);tone(880,.1,.16,'sine',.09)},
  minimize:()=>tone(420,0,.08,'triangle',.07),
  maximize:()=>{tone(440,0,.07,'triangle',.07);tone(660,.06,.1,'triangle',.07)},
  connect:()=>{tone(520,0,.1,'sine',.1);tone(780,.1,.18,'sine',.1)},
  disconnect:()=>{tone(780,0,.1,'sine',.1);tone(520,.1,.18,'sine',.1)},
notification:()=>{tone(740,0,.08,'sine',.08);tone(980,.09,.16,'sine',.08)},
warning:()=>{tone(300,0,.12,'triangle',.1);tone(260,.13,.18,'triangle',.1)}
};
let chimed=false;
function chimeOnce(){if(chimed)return;chimed=true;sfx.chime()}
document.addEventListener('pointerdown',e=>{
  if(e.target.closest('button,.icon,.item,.task,.file,#ctx div'))sfx.click();
},true);

/* ---------- cursor and background ---------- */
function applyLook(){
  const d=$('#desktop');
  document.documentElement.style.setProperty('--accent',S.accent||'#2787d8');
  const palette=S.theme==='light'?['#f3f6fb','#ffffff','#e8edf5','#cbd4e2','#172033','#586579']:['#0b1220','#141c33','#1b2544','#2a3760','#e8edf8','#8d9bbd'];
  ['--bg','--panel','--panel2','--line','--text','--muted'].forEach((k,i)=>document.documentElement.style.setProperty(k,palette[i]));
  document.documentElement.style.fontSize=S.uiSize==='large'?'17px':S.uiSize==='compact'?'13px':'15px';
  document.documentElement.style.scrollBehavior=S.reduceMotion?'auto':'smooth';
  d.style.backgroundColor=S.bg;
  d.style.backgroundImage=S.bgImg?`url(${S.bgImg})`:(S.bgGrad||'none');
  if(!cursorStyle){cursorStyle=el('style');document.head.appendChild(cursorStyle)}
  let c=S.cursor||'default';
  if(S.cursorImg)c=`url(${S.cursorImg}) 0 0, auto`;
  cursorStyle.textContent=`html,body,#desktop{cursor:${c}}`;
}
function readFile(f,cb){const r=new FileReader();r.onload=()=>cb(r.result);r.readAsDataURL(f)}

/* ---------- boot and lock ---------- */
function boot(){
  const b=$('#boot');
  b.innerHTML=`<div>${esc(S.bootText)}</div><div style="font-size:14px;opacity:.6">Starting Browser OS…</div>`;
  try{
    if(S.sound){
      actx=new (window.AudioContext||window.webkitAudioContext)();
      if(actx.state==='running'){chimed=true;sfx.chime()}
      else{actx.close();actx=null}
    }
  }catch(e){}
  setTimeout(()=>{b.classList.add('hidden');if(!S.setupComplete)showFirstRunSetup();else showLock()},900);
}
function showLock(){
  const l=$('#lock');l.classList.remove('hidden');
  l.innerHTML=`<div class="bos-lock-card"><div class="setup-logo">▦</div><h1>Welcome back, ${esc(S.profileName||'User')}</h1><p>Sign in to Browser OS</p><input id="pw" type="password" placeholder="Password" autocomplete="current-password"><button id="pwok">Sign in</button><div id="pwerr" class="bos-error"></div><small>${esc(S.deviceName||'BROWSER-OS')}</small></div>`;
  const go=()=>{
    if(!S.pass || $('#pw').value===S.pass){l.classList.add('hidden');chimeOnce();start()}
    else{$('#pwerr').textContent='That password is incorrect. Try again.';sfx.error();$('#pw').select()}
  };
  $('#pwok').onclick=go;$('#pw').onkeydown=e=>{if(e.key==='Enter')go()};$('#pw').focus();
}
function showFirstRunSetup(){
  const l=$('#lock');l.classList.remove('hidden');
  l.innerHTML=`<div class="oobe"><div class="oobe-top"><span class="setup-logo">▦</span><span>Browser OS Setup</span></div><div class="oobe-content">
  <div class="oobe-step">LET'S SET THINGS UP</div><h1>Let's start with the basics.</h1><p>Choose your preferences and create your Browser OS profile.</p>
  <div class="oobe-grid">
  <label>Country or region<select id="o-region"><option>United States</option><option>Canada</option><option>United Kingdom</option><option>Australia</option><option>India</option><option>Germany</option><option>France</option><option>Japan</option><option>Other</option></select></label>
  <label>Display language<select id="o-lang"><option>English (United States)</option><option>English (United Kingdom)</option><option>Spanish</option><option>French</option><option>German</option><option>Japanese</option><option>Portuguese</option><option>Other</option></select></label>
  <label>Keyboard layout<select id="o-key"><option>US</option><option>United Kingdom</option><option>Canadian Multilingual</option><option>German</option><option>French</option><option>Japanese</option></select></label>
  <label>Profile name<input id="o-user" maxlength="32" placeholder="What should we call you?"></label>
  <label>Device name<input id="o-device" maxlength="32" value="BROWSER-OS"></label>
  <label>Create a password<input id="o-pass" type="password" autocomplete="new-password" placeholder="Choose a password"></label>
  <label>Confirm password<input id="o-confirm" type="password" autocomplete="new-password" placeholder="Enter it again"></label>
  <label>Time format<select id="o-time"><option value="12">12-hour clock</option><option value="24">24-hour clock</option></select></label>
  </div>
  <div class="oobe-options"><label><input type="checkbox" id="o-location"> Allow location access when a feature requests it</label><label><input type="checkbox" id="o-diagnostics" checked> Send optional usage diagnostics (stored locally only)</label><label><input type="checkbox" id="o-sound" checked> Enable system sounds</label></div>
  <div class="bos-error" id="o-error"></div><div class="oobe-actions"><span>Step 1 of 1 · You can change preferences later in Settings</span><button id="o-finish">Accept and continue</button></div>
  </div></div>`;
  $('#o-finish').onclick=()=>{
    const pw=$('#o-pass').value, confirm=$('#o-confirm').value;
    if(pw!==confirm){$('#o-error').textContent='Your passwords do not match.';return}
    if(pw.length>0&&pw.length<4){$('#o-error').textContent='Use at least 4 characters for your password.';return}
    S.region=$('#o-region').value;S.language=$('#o-lang').value;S.keyboard=$('#o-key').value;
    S.profileName=$('#o-user').value.trim()||'User';S.deviceName=$('#o-device').value.trim()||'BROWSER-OS';
    S.pass=pw;S.timeFormat=$('#o-time').value;S.locationConsent=$('#o-location').checked;
    S.diagnostics=$('#o-diagnostics').checked;S.sound=$('#o-sound').checked;S.accent=S.accent||'#2787d8';S.searchEngine=S.searchEngine||'google';S.uiSize=S.uiSize||'normal';S.setupComplete=true;
    save();l.classList.add('hidden');applyLook();start();
  };
}
let started=false;
function start(){
  $('#desktop').classList.remove('hidden');applyLook();
  if(started)return;started=true;
  renderIcons();renderStart();renderPinned();tick();setInterval(tick,1000);
  if(!chimed&&S.sound){
    const once=()=>{chimeOnce();document.removeEventListener('pointerdown',once,true)};
    document.addEventListener('pointerdown',once,true);
  }
}
function tick(){$('#clock').textContent=new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',...(S.showSeconds?{second:'2-digit'}:{}),hour12:S.timeFormat!=='24'})+(S.showDate===false?'':'\n'+new Date().toLocaleDateString())}

/* ---------- built-in apps ---------- */
const builtin=[
  {id:'files',name:'File Explorer',emoji:'📁',open:()=>openFiles()},
  {id:'browser',name:'Browser',emoji:'🌐',open:()=>openBrowser()},
  {id:'notes',name:'Notepad',emoji:'📝',open:()=>openNotes()},
  {id:'calc',name:'Calculator',emoji:'🧮',open:()=>openCalc()},
  {id:'settings',name:'Settings',emoji:'⚙️',open:()=>openSettings()},
  {id:'paint',name:'Paint',emoji:'🎨',open:()=>openPaint()},
  {id:'calendar',name:'Calendar',emoji:'📅',open:()=>openCalendar()},
  {id:'clockapp',name:'Clock',emoji:'⏰',open:()=>openClock()},
  {id:'media',name:'Media Player',emoji:'🎵',open:()=>openMedia()},
  {id:'terminal',name:'Terminal',emoji:'⌨️',open:()=>openTerminal()},
  {id:'taskmgr',name:'Task Manager',emoji:'📊',open:()=>openTaskManager()},
  {id:'photos',name:'Photos',emoji:'🖼️',open:()=>openPhotos()},
  {id:'downloads',name:'Downloads',emoji:'⬇️',open:()=>openDownloads()},
  {id:'todo',name:'To Do',emoji:'☑️',open:()=>openTodo()},
  {id:'sticky',name:'Sticky Notes',emoji:'🗒️',open:()=>openSticky()},
  {id:'units',name:'Unit Converter',emoji:'📐',open:()=>openUnitConverter()},
  {id:'focus',name:'Focus Timer',emoji:'🍅',open:()=>openFocusTimer()},
  {id:'monitor',name:'System Monitor',emoji:'📈',open:()=>openSystemMonitor()},
  {id:'setup',name:'Setup',emoji:'🪟',open:()=>openSetup()},
  {id:'system',name:'System Information',emoji:'ℹ️',open:()=>openSystemInfo()}
];
/* ---------- which apps live where ---------- */
const VERSION='2.5.0';
const DESK_DEFAULT=['notes','browser','settings','files','calc','photos','paint'];
const START_MAIN=DESK_DEFAULT;
const PIN_DEFAULT=['browser','files','settings'];
function migrate(){
  if(!Array.isArray(S.apps))S.apps=[];
  if(!Array.isArray(S.deskApps)){
    const hidden=S.hiddenApps||[];
    S.deskApps=DESK_DEFAULT.concat(S.apps.map(a=>a.id)).filter(id=>!hidden.includes(id));
  }
  if(!Array.isArray(S.pinned))S.pinned=[];
  if(!S.pinDefaultsDone){PIN_DEFAULT.forEach(id=>{if(!S.pinned.includes(id))S.pinned.push(id)});S.pinDefaultsDone=true}
  S.deskApps=S.deskApps.filter(id=>id!=='control');
  S.pinned=S.pinned.filter(id=>id!=='control');
}
function setDesk(id,on){S.deskApps=(S.deskApps||[]).filter(x=>x!==id);if(on)S.deskApps.push(id);save()}
function uninstallApp(id){S.apps=S.apps.filter(x=>x.id!==id);S.deskApps=(S.deskApps||[]).filter(x=>x!==id);S.pinned=(S.pinned||[]).filter(x=>x!==id);save();renderIcons();renderStart();renderPinned()}
function lockNow(){const m=$('#startmenu');if(m)m.classList.add('hidden');if(S.pass){$('#desktop').classList.add('hidden');showLock()}else alert('Set a password in Settings > Accounts first.')}
/* ---------- search engines ---------- */
const ENGINES={
  google:['Google','https://www.google.com/search?igu=1&q='],
  bing:['Bing','https://www.bing.com/search?q='],
  duck:['DuckDuckGo','https://duckduckgo.com/?q='],
  yahoo:['Yahoo','https://search.yahoo.com/search?p='],
  brave:['Brave Search','https://search.brave.com/search?q='],
  ecosia:['Ecosia','https://www.ecosia.org/search?q='],
  startpage:['Startpage','https://www.startpage.com/do/search?q='],
  qwant:['Qwant','https://www.qwant.com/?q='],
  yandex:['Yandex','https://yandex.com/search/?text='],
  baidu:['Baidu','https://www.baidu.com/s?wd='],
  ask:['Ask.com','https://www.ask.com/web?q='],
  aol:['AOL Search','https://search.aol.com/aol/search?q='],
  mojeek:['Mojeek','https://www.mojeek.com/search?q='],
  swisscows:['Swisscows','https://swisscows.com/en/web?query='],
  perplexity:['Perplexity','https://www.perplexity.ai/search?q='],
  youtube:['YouTube','https://www.youtube.com/results?search_query='],
  wikipedia:['Wikipedia','https://en.wikipedia.org/w/index.php?search=']
};
function searchUrl(text){
  const q=encodeURIComponent(text),id=S.searchEngine||'google';
  if(id==='custom'&&S.customSearch&&S.customSearch.includes('%s'))return S.customSearch.replace('%s',q);
  return (ENGINES[id]||ENGINES.google)[1]+q;
}
function faviconFor(url){try{return 'https://www.google.com/s2/favicons?sz=64&domain='+new URL(url).hostname}catch(e){return ''}}
function iconHTML(a){
  if(a.emoji)return `<div class="emoji">${a.emoji}</div>`;
  return `<img src="${esc(a.icon||faviconFor(a.url))}">`;
}
/* small icon used in the taskbar and window title bars; falls back to a globe if the image fails */
function smallIcon(a){
  if(a.emoji){const d=el('div','emoji',a.emoji);return d}
  const i=el('img');i.src=a.icon||faviconFor(a.url);
  i.onerror=()=>{i.replaceWith(el('div','emoji','🌐'))};
  return i;
}
function allApps(){return builtin.concat(S.apps.map(a=>({...a,open:()=>openSite(a.url,a.name,a)})))}
/* ---------- pinned apps on the taskbar ---------- */
function isPinned(id){return (S.pinned||[]).includes(id)}
function pinApp(id){if(!Array.isArray(S.pinned))S.pinned=[];if(!S.pinned.includes(id))S.pinned.push(id);save();renderPinned()}
function unpinApp(id){S.pinned=(S.pinned||[]).filter(x=>x!==id);save();renderPinned()}
function pinMenuItem(id){return isPinned(id)?['Unpin from taskbar',()=>unpinApp(id)]:['Pin to taskbar',()=>pinApp(id)]}
function renderPinned(){
  let box=$('#pinned');
  if(!box){box=el('div');box.id='pinned';$('#taskbar').insertBefore(box,$('#tasks'))}
  box.innerHTML='';
  const apps=allApps();
  const valid=(S.pinned||[]).filter(id=>apps.some(a=>a.id===id));
  if(valid.length!==(S.pinned||[]).length){S.pinned=valid;save()}
  valid.forEach(id=>{
    const a=apps.find(x=>x.id===id);
    const b=el('div','task pin');b.title=a.name;b.appendChild(smallIcon(a));
    b.onclick=()=>a.open();
    b.oncontextmenu=e=>{e.preventDefault();e.stopPropagation();menu(e.clientX,e.clientY,[['Open',a.open],['Unpin from taskbar',()=>unpinApp(id)]])};
    box.appendChild(b);
  });
  box.classList.toggle('has-pins',valid.length>0);
}

/* ---------- desktop icons: movable, removable, with folders and files ---------- */
function deskDirFind(){return (S.fs.kids||[]).find(k=>k.type==='dir'&&k.id==='desktop')||null}
function deskDir(){let d=deskDirFind();if(!d){d={id:'desktop',type:'dir',name:'Desktop',kids:[]};S.fs.kids.push(d)}return d}
function deskItems(){
  const on=S.deskApps||[];
  const apps=allApps().filter(a=>on.includes(a.id)).map(a=>({key:'app:'+a.id,app:a}));
  const d=deskDirFind();
  const nodes=((d&&d.kids)||[]).map(k=>({key:'node:'+k.id,node:k}));
  return apps.concat(nodes);
}
function deskSig(){
  const d=deskDirFind();
  return JSON.stringify([S.deskApps,S.apps.map(a=>a.id+'|'+a.name),((d&&d.kids)||[]).map(k=>k.id+'|'+k.name)]);
}
function pathTo(id,n=S.fs,acc=[]){
  const here=acc.concat(n.id);
  if(n.id===id)return here;
  for(const k of n.kids||[]){if(k.type==='dir'){const r=pathTo(id,k,here);if(r)return r}}
  return null;
}
/* icons sit on a grid and can never overlap */
const ICON_W=84,ICON_H=90,GRID_MARGIN=10;
/* the grid is stretched so the first and last column/row touch the margins: icons can sit exactly in all four corners */
function gridDims(){
  const W=innerWidth,H=innerHeight-46;
  const cols=Math.max(1,Math.floor((W-2*GRID_MARGIN)/(ICON_W+12)));
  const rows=Math.max(1,Math.floor((H-2*GRID_MARGIN)/(ICON_H+10)));
  const stepX=cols>1?(W-2*GRID_MARGIN-ICON_W)/(cols-1):0;
  const stepY=rows>1?(H-2*GRID_MARGIN-ICON_H)/(rows-1):0;
  return {cols,rows,stepX,stepY};
}
function cellOf(p){const g=gridDims();return {c:g.stepX?Math.max(0,Math.min(g.cols-1,Math.round((p.x-GRID_MARGIN)/g.stepX))):0,r:g.stepY?Math.max(0,Math.min(g.rows-1,Math.round((p.y-GRID_MARGIN)/g.stepY))):0}}
function cellPos(c){const g=gridDims();return {x:Math.round(GRID_MARGIN+c.c*g.stepX),y:Math.round(GRID_MARGIN+c.r*g.stepY)}}
function nearestFreeCell(want,used){
  const g=gridDims();let best=null,bd=Infinity;
  for(let c=0;c<g.cols;c++)for(let r=0;r<g.rows;r++){
    if(used.has(c+','+r))continue;
    const d=(c-want.c)**2+(r-want.r)**2;
    if(d<bd){bd=d;best={c,r}}
  }
  return best||want;
}
function makeIconDraggable(i,key){
  i.onpointerdown=e=>{
    if(e.button!==0)return;
    const box=$('#icons'),sx=e.clientX,sy=e.clientY,ox=i.offsetLeft,oy=i.offsetTop;let moved=false;
    const mv=ev=>{
      const dx=ev.clientX-sx,dy=ev.clientY-sy;
      if(!moved&&Math.hypot(dx,dy)<5)return;
      moved=true;i.classList.add('dragging');
      i.style.left=Math.max(0,Math.min(ox+dx,box.clientWidth-i.offsetWidth))+'px';
      i.style.top=Math.max(0,Math.min(oy+dy,box.clientHeight-i.offsetHeight))+'px';
    };
    const up=()=>{
      removeEventListener('pointermove',mv);removeEventListener('pointerup',up);removeEventListener('pointercancel',up);
      i.classList.remove('dragging');
      if(moved){
        const used=new Set();
        deskItems().forEach(it=>{if(it.key!==key&&S.iconPos[it.key]){const c=cellOf(S.iconPos[it.key]);used.add(c.c+','+c.r)}});
        const cell=nearestFreeCell(cellOf({x:i.offsetLeft,y:i.offsetTop}),used);
        const p=cellPos(cell);S.iconPos[key]=p;i.style.left=p.x+'px';i.style.top=p.y+'px';save();
      }
    };
    addEventListener('pointermove',mv);addEventListener('pointerup',up);addEventListener('pointercancel',up);
  };
}
function renderIcons(preview){
  const box=$('#icons');box.innerHTML='';
  if(!S.iconPos)S.iconPos={};
  const backup=preview?JSON.stringify(S.iconPos):null;
  const items=deskItems();
  /* snap every icon to the grid; if two share a cell, the later one moves to the nearest free cell */
  const used=new Set();let assigned=false;
  items.forEach(it=>{
    const old=S.iconPos[it.key];if(!old)return;
    let cell=cellOf(old);
    if(used.has(cell.c+','+cell.r))cell=nearestFreeCell(cell,used);
    used.add(cell.c+','+cell.r);
    const p=cellPos(cell);
    if(p.x!==old.x||p.y!==old.y){S.iconPos[it.key]=p;assigned=true}
  });
  const g=gridDims();let n=0;
  items.forEach(it=>{
    if(S.iconPos[it.key])return;
    let cell;
    do{cell={c:Math.floor(n/g.rows),r:n%g.rows};n++}while(used.has(cell.c+','+cell.r)&&n<g.cols*g.rows+1);
    if(used.has(cell.c+','+cell.r))cell=nearestFreeCell(cell,used);
    used.add(cell.c+','+cell.r);S.iconPos[it.key]=cellPos(cell);assigned=true;
  });
  items.forEach(it=>{
    const p=S.iconPos[it.key];let i;
    if(it.app){
      const a=it.app;
      i=el('div','icon',iconHTML(a)+esc(a.name));
      const img=i.querySelector('img');if(img)img.onerror=()=>{img.replaceWith(el('div','emoji','🌐'))};
      i.ondblclick=a.open;
      i.oncontextmenu=e=>{e.stopPropagation();e.preventDefault();
        menu(e.clientX,e.clientY,[['Open',a.open],pinMenuItem(a.id),['Remove app',()=>setDesk(a.id,false)]])};
    }else{
      const k=it.node;
      i=el('div','icon',`<div class="emoji">${fileIcon(k)}</div>${esc(k.name)}`);
      const open=()=>k.type==='dir'?openFiles(k.id):openFileNode(k);
      i.ondblclick=open;
      i.oncontextmenu=e=>{e.stopPropagation();e.preventDefault();
        menu(e.clientX,e.clientY,[['Open',open],['Rename',()=>{const nn=prompt('Rename item',k.name);if(nn){k.name=nn;save()}}],
          ['Delete',()=>{if(confirm('Delete '+k.name+'?')){const d=deskDirFind();d.kids=d.kids.filter(x=>x!==k);delete S.iconPos[it.key];save()}}]])};
    }
    i.ondragstart=e=>e.preventDefault();i.querySelectorAll('img').forEach(im=>im.draggable=false);
    i.style.left=p.x+'px';i.style.top=p.y+'px';
    makeIconDraggable(i,it.key);
    box.appendChild(i);
  });
  lastDeskSig=deskSig();
  if(preview){S.iconPos=JSON.parse(backup)}else if(assigned)save();
}
let resizeTimer=null;
addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{if(started)renderIcons(true)},150)});
function renderStart(){
  const m=$('#startmenu');m.innerHTML='';
  const apps=allApps();
  const search=el('input','start-search');search.type='search';search.placeholder='Search apps…';search.setAttribute('aria-label','Search apps');
  const scroll=el('div','start-scroll');
  const mk=a=>{
    const i=el('div','item',iconHTML(a).replace('class="emoji"','style="font-size:28px;line-height:32px"')+'<span>'+esc(a.name)+'</span>');
    i.dataset.name=a.name.toLowerCase();
    const im=i.querySelector('img');if(im)im.onerror=()=>im.replaceWith(el('div','emoji','🌐'));
    i.onclick=()=>{a.open();m.classList.add('hidden')};
    i.oncontextmenu=e=>{e.stopPropagation();e.preventDefault();
      const onDesk=(S.deskApps||[]).includes(a.id);
      const opts=[['Open',a.open],pinMenuItem(a.id),onDesk?['Remove from desktop',()=>setDesk(a.id,false)]:['Add to desktop',()=>setDesk(a.id,true)]];
      if(a.url)opts.push(['Uninstall app',()=>uninstallApp(a.id)]);
      menu(e.clientX,e.clientY,opts)};
    return i;
  };
  /* group 1: the main apps, group 2: everything else, group 3: websites you added */
  const groups=[
    ['Main apps',START_MAIN.map(id=>apps.find(a=>a.id===id)).filter(Boolean)],
    ['Other apps',apps.filter(a=>!a.url&&!START_MAIN.includes(a.id))],
    ['Websites',apps.filter(a=>a.url)]
  ];
  groups.forEach(([title,list])=>{
    if(!list.length)return;
    const g=el('div','start-group');g.appendChild(el('h5','',esc(title)));
    const grid=el('div','start-grid');list.forEach(a=>grid.appendChild(mk(a)));g.appendChild(grid);scroll.appendChild(g);
  });
  const none=el('div','start-none','No apps match your search.');none.style.display='none';scroll.appendChild(none);
  search.oninput=()=>{
    const q=search.value.trim().toLowerCase();let any=false;
    scroll.querySelectorAll('.start-group').forEach(g=>{
      let vis=0;
      g.querySelectorAll('.item').forEach(i=>{const show=!q||i.dataset.name.includes(q);i.style.display=show?'':'none';if(show)vis++});
      g.style.display=vis?'':'none';if(vis)any=true;
    });
    none.style.display=any?'none':'';
  };
  search.onkeydown=e=>{if(e.key==='Enter'){const f=[...scroll.querySelectorAll('.item')].find(i=>i.style.display!=='none');if(f)f.click()}};
  const foot=el('div','start-foot');
  foot.appendChild(el('span','','👤 '+esc(S.profileName||'User')));
  const right=el('div','start-foot-btns');
  const st=el('button','','⚙️ Settings');st.onclick=()=>{m.classList.add('hidden');openSettings()};
  const lk=el('button','','🔒 Lock');lk.onclick=lockNow;
  right.append(st,lk);foot.appendChild(right);
  m.append(search,scroll,foot);
  m.onclick=e=>{e.stopPropagation();$('#ctx').classList.add('hidden')};
}
$('#startbtn').innerHTML='<span class="os-logo"><i></i><i></i><i></i><i></i></span>';
$('#startbtn').title='Browser OS Start';
$('#startbtn').onclick=e=>{
  e.stopPropagation();$('#ctx').classList.add('hidden');
  const m=$('#startmenu'),opening=m.classList.contains('hidden');
  m.classList.toggle('hidden');
  if(opening){const q=m.querySelector('.start-search');if(q){q.value='';q.oninput();q.focus()}}
};

/* ---------- context menu ---------- */
function menu(x,y,items){
  const c=$('#ctx');c.innerHTML='';
  items.forEach(([t,f])=>{const d=el('div','',esc(t));d.onclick=()=>{c.classList.add('hidden');f()};c.appendChild(d)});
  c.style.left=Math.min(x,innerWidth-190)+'px';c.style.top=Math.min(y,innerHeight-items.length*34-60)+'px';
  c.classList.remove('hidden');
}
document.addEventListener('click',()=>{$('#ctx').classList.add('hidden');$('#startmenu').classList.add('hidden')});
$('#desktop').addEventListener('contextmenu',e=>{
  e.preventDefault();
  const px=e.clientX,py=e.clientY;
  const place=node=>{if(!S.iconPos)S.iconPos={};S.iconPos['node:'+node.id]={x:Math.max(0,Math.min(px-40,innerWidth-90)),y:Math.max(0,Math.min(py-30,innerHeight-150))}};
  menu(px,py,[
    ['New folder',()=>{const name=prompt('Folder name','New folder');if(!name)return;const node={id:uid(),type:'dir',name,kids:[]};deskDir().kids.push(node);place(node);save()}],
    ['New file',()=>{const name=prompt('File name (include the extension)','New file.txt');if(!name)return;const node={id:uid(),type:'file',name,text:'',mime:guessMime(name)};deskDir().kids.push(node);place(node);save()}],
    ['Add app',addAppDialog],['Change background',()=>openSettings('personal')],['Settings',()=>openSettings()]]);
});

/* ---------- add app dialog ---------- */
function addAppDialog(onDone){
  const m=el('div','modal',`<div class="box"><b>Add an app</b>
    <label>Website of app<input id="aaurl" placeholder="https://example.com"></label>
    <label>Name<input id="aaname"></label>
    <label>Icon (optional, uses the site icon if empty)<input id="aaicon" type="file" accept="image/*"></label>
    <div style="display:flex;gap:8px;justify-content:flex-end"><button class="btn alt" id="aacancel">Cancel</button><button class="btn" id="aaok">Add</button></div></div>`);
  document.body.appendChild(m);
  $('#aacancel').onclick=()=>m.remove();
  $('#aaok').onclick=()=>{
    let url=$('#aaurl').value.trim();if(!url)return;
    if(!/^https?:\/\//i.test(url))url='https://'+url;
    let name=$('#aaname').value.trim();
    if(!name){try{name=new URL(url).hostname.replace('www.','')}catch(e){name='App'}}
    const f=$('#aaicon').files[0];
    const done=icon=>{const id=uid();S.apps.push({id,name,url,icon:icon||faviconFor(url)});if(!Array.isArray(S.deskApps))S.deskApps=[];S.deskApps.push(id);save();renderIcons();renderStart();m.remove();sfx.open();if(typeof onDone==='function')onDone()};
    f?readFile(f,done):done('');
  };
}

/* ---------- window manager ---------- */
/* app = the app object (emoji or icon) so the taskbar and title bar can show its icon */
function openWin(title,w,h,build,app){
  const id=uid();
  const win=el('div','win');
  const n=Object.keys(wins).length;
  win.style.cssText=`width:${w}px;height:${h}px;left:${60+n*28}px;top:${40+n*28}px;z-index:${++z}`;
  const bar=el('div','bar',`<span class="title">${esc(title)}</span><button title="Minimize">－</button><button title="Maximize / Restore">□</button><button title="Close">✕</button>`);
  const body=el('div','body');
  win.append(bar,body);$('#windows').appendChild(win);
  const task=el('div','task');task.title=title;
  const ic=app||{emoji:'📄'};
  task.appendChild(smallIcon(ic));
  const barIcon=smallIcon(ic);if(barIcon.tagName==='IMG')bar.insertBefore(barIcon,bar.firstChild);
  $('#tasks').appendChild(task);
  wins[id]={win,task,close:null,maximize:null,minimize:null};
  sfx.open();
  const focus=()=>{win.style.zIndex=++z;Object.values(wins).forEach(o=>o.task.classList.remove('active'));task.classList.add('active')};
  const close=()=>{win.remove();task.remove();delete wins[id];sfx.close()};
  const minimize=()=>{win.classList.add('hidden');sfx.minimize()};
  const maximize=()=>{if(!max){prev=win.style.cssText;win.style.left='0px';win.style.top='0px';win.style.width='100%';win.style.height='calc(100% - 46px)';max=true;sfx.maximize()}else{win.style.cssText=prev;max=false;sfx.maximize()}};
  Object.assign(wins[id],{close,minimize,maximize});
  task.oncontextmenu=e=>{e.preventDefault();e.stopPropagation();menu(e.clientX,e.clientY,[['Restore',()=>{win.classList.remove('hidden');focus()}],['Minimize',minimize],['Maximize / Restore',maximize],['Close window',close]])};
  win.addEventListener('mousedown',focus);focus();
  task.onclick=()=>{
    if(win.classList.contains('hidden')){win.classList.remove('hidden');focus()}
    else if(task.classList.contains('active'))win.classList.add('hidden');
    else focus();
  };
  const btns=bar.querySelectorAll('button');
  let max=false,prev='';
  btns[0].onclick=minimize;
  btns[1].onclick=maximize;
  btns[2].onclick=close;
  bar.onmousedown=e=>{
    if(e.target.tagName==='BUTTON'||max)return;
    const ox=e.clientX-win.offsetLeft,oy=e.clientY-win.offsetTop;
    const mv=ev=>{win.style.left=ev.clientX-ox+'px';win.style.top=Math.max(0,ev.clientY-oy)+'px'};
    const up=()=>{removeEventListener('mousemove',mv);removeEventListener('mouseup',up)};
    addEventListener('mousemove',mv);addEventListener('mouseup',up);
  };
  build(body,close);
  return win;
}

/* ---------- websites open as real Chrome windows, tracked on the Browser OS taskbar ---------- */
const sites={};
let mainWinId=null,lastMainPos=null;
if(window.chrome&&chrome.windows){chrome.windows.getCurrent().then(m=>{mainWinId=m.id;lastMainPos={left:m.left,top:m.top}}).catch(()=>{})}
async function osArea(){
  const main=await chrome.windows.getCurrent();
  const border=Math.max(0,Math.round((window.outerWidth-window.innerWidth)/2));
  return {left:main.left+border,top:main.top+(window.outerHeight-window.innerHeight)-border,width:window.innerWidth,height:window.innerHeight-46};
}
function siteKeyFor(winId){return Object.keys(sites).find(k=>sites[k].winId===winId)}
function closeSite(key){const s=sites[key];if(s&&window.chrome&&chrome.windows)chrome.windows.remove(s.winId).catch(()=>{})}
async function focusSite(key){
  const s=sites[key];if(!s)return;
  try{await chrome.windows.update(s.winId,{state:'normal',focused:true})}catch(e){s.task.remove();delete sites[key]}
}
async function openSite(url,title,app){
  if(!url)return;
  app=app||{};
  const key=app.id||uid();
  if(sites[key]){await focusSite(key);if(sites[key])return}
  if(!(window.chrome&&chrome.windows)){window.open(url,'_blank','popup,width=1100,height=700');return}
  const area=await osArea();
  const width=Math.min(1200,area.width-60),height=Math.min(800,area.height-40);
  const off=Object.keys(sites).length*28;
  const created=await chrome.windows.create({url,type:'popup',left:Math.round(area.left+(area.width-width)/2+off),top:Math.round(area.top+20+off),width:Math.round(width),height:Math.round(height),focused:true});
  const ic={name:title||app.name||url,url,icon:app.icon,emoji:app.emoji};
  const task=el('div','task');task.title=ic.name;task.appendChild(smallIcon(ic));
  task.classList.add('active');
  task.onclick=()=>focusSite(key);
  task.oncontextmenu=e=>{e.preventDefault();e.stopPropagation();menu(e.clientX,e.clientY,[['Restore',()=>focusSite(key)],...(allApps().some(a=>a.id===key)?[pinMenuItem(key)]:[]),['Minimize',()=>chrome.windows.update(sites[key].winId,{state:'minimized'}).catch(()=>{})],['Close window',()=>closeSite(key)]])};
  $('#tasks').appendChild(task);
  sites[key]={winId:created.id,task};
  sfx.open();
}
if(window.chrome&&chrome.windows){
  const ignoreUntil={},snapTimers={},lastSeen={},minimizedWithOS={};
  async function keepInside(winId){
    let f;try{f=await chrome.windows.get(winId)}catch(e){return}
    if(f.state!=='normal')return;
    const a=await osArea();
    const w=Math.min(f.width,a.width),h=Math.min(f.height,a.height);
    const left=Math.round(Math.min(Math.max(f.left,a.left),a.left+a.width-w)),top=Math.round(Math.min(Math.max(f.top,a.top),a.top+a.height-h));
    const outside=Math.abs(left-f.left)>16||Math.abs(top-f.top)>16,tooBig=f.width>a.width+16||f.height>a.height+16;
    if(!outside&&!tooBig)return;
    const u={left,top};if(tooBig){u.width=Math.round(w);u.height=Math.round(h)}
    ignoreUntil[winId]=Date.now()+800;chrome.windows.update(winId,u).catch(()=>{});
  }
  chrome.windows.onBoundsChanged.addListener(async changed=>{
    if(changed.id===mainWinId){
      const dx=lastMainPos?changed.left-lastMainPos.left:0,dy=lastMainPos?changed.top-lastMainPos.top:0;
      lastMainPos={left:changed.left,top:changed.top};
      if(!dx&&!dy)return;
      for(const k of Object.keys(sites)){
        try{const f=await chrome.windows.get(sites[k].winId);if(f.state!=='normal')continue;ignoreUntil[f.id]=Date.now()+800;await chrome.windows.update(f.id,{left:f.left+dx,top:f.top+dy})}catch(e){}
      }
      return;
    }
    if(!siteKeyFor(changed.id)||Date.now()<(ignoreUntil[changed.id]||0))return;
    clearTimeout(snapTimers[changed.id]);snapTimers[changed.id]=setTimeout(()=>keepInside(changed.id),150);
  });
  setInterval(async()=>{
    const keys=Object.keys(sites);if(!keys.length||mainWinId===null)return;
    let main;try{main=await chrome.windows.get(mainWinId)}catch(e){return}
    for(const k of keys){
      const s=sites[k];if(!s)continue;
      let f;try{f=await chrome.windows.get(s.winId)}catch(e){continue}
      s.task.classList.toggle('active',f.state!=='minimized');
      if(main.state==='minimized'){if(f.state!=='minimized'){minimizedWithOS[s.winId]=f.state;chrome.windows.update(s.winId,{state:'minimized'}).catch(()=>{})}continue}
      if(minimizedWithOS[s.winId]){const prev=minimizedWithOS[s.winId];delete minimizedWithOS[s.winId];chrome.windows.update(s.winId,{state:prev}).catch(()=>{});continue}
      const b=[f.left,f.top,f.width,f.height,f.state].join(',');
      if(lastSeen[s.winId]===b)keepInside(s.winId);
      lastSeen[s.winId]=b;
    }
  },250);
  chrome.windows.onRemoved.addListener(winId=>{const k=siteKeyFor(winId);if(k){sites[k].task.remove();delete sites[k];sfx.close()}});
  window.addEventListener('pagehide',()=>{Object.keys(sites).forEach(closeSite)});
}

/* ---------- browser app ---------- */
function openBrowser(url,title,app){
  openWin(title||'Browser',1000,650,body=>{
    const tabs=el('div','browser-tabs');
    const row=el('div','row',`
      <button title="Back">◀</button><button title="Forward">▶</button><button title="Reload">⟳</button>
      <input class="browser-address" placeholder="Search or enter a website address…" spellcheck="false">
      <button class="browser-go">Go</button><button class="browser-bookmark" title="Bookmark this page">☆</button><button class="browser-newtab" title="New tab">＋</button><button class="browser-external" title="Open current page in Chrome">↗</button>
    `);
    const bookmarks=el('div','browser-bookmarks');
    const frame=el('iframe');frame.setAttribute('referrerpolicy','strict-origin-when-cross-origin');frame.setAttribute('allow','fullscreen; autoplay; clipboard-read; clipboard-write');frame.setAttribute('sandbox','allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-downloads allow-presentation');
    const status=el('div','browser-status','Ready');
    body.append(tabs,row,bookmarks,frame,status);
    const address=row.querySelector('.browser-address'),go=row.querySelector('.browser-go');
    let pages=[],active=0;
    const normalize=value=>{
      let v=value.trim();if(!v)return '';
      if(/^https?:\/\//i.test(v))return v;
      if(/^[\w-]+(\.[\w-]+)+([/:?#].*)?$/i.test(v)&&!/\s/.test(v)){
        let u='https://'+v;
        if(/^https?:\/\/(www\.)?google\.com\/?$/i.test(u))return 'https://www.google.com/webhp?igu=1';
        return u;
      }
      return searchUrl(v);
    };
    if(!Array.isArray(S.bookmarks))S.bookmarks=[];
    function drawBookmarks(){bookmarks.innerHTML='';S.bookmarks.forEach(bm=>{const b=el('button','bookmark-chip',esc(bm.name));b.title=bm.url;b.onclick=()=>openSite(bm.url,bm.name,{name:bm.name,icon:faviconFor(bm.url)});bookmarks.appendChild(b)})}
    const current=()=>pages[active];
    function renderTabs(){
      tabs.innerHTML='';
      pages.forEach((p,i)=>{
        const b=el('button','browser-tab'+(i===active?' active':''),`${i===active?'●':'○'} ${esc(p.label||'New Tab')}  ×`);
        b.title=p.url||'New tab';
        b.onclick=()=>{if(i===active){if(pages.length>1){pages.splice(i,1);active=Math.max(0,i-1);renderTabs();showPage()}}else{active=i;renderTabs();showPage()}};
        tabs.appendChild(b);
      });
    }
    function showPage(){
      const p=current();address.value=p.url||'';frame.src=p.url||'about:blank';
      if(!p.url)frame.srcdoc='<body style="font:16px Segoe UI,sans-serif;padding:42px;background:#f5f8ff;color:#18243a"><h1>Browser</h1><p>Search the web or enter a website address above.</p><p>Your pages stay in this Browser OS window. Some websites restrict embedded viewing.</p></body>';
      status.textContent=p.url?'Loading inside Browser OS…':'New tab';
      row.children[0].disabled=p.back.length===0;row.children[1].disabled=p.forward.length===0;
    }
    function navigate(value,record=true){
      const target=normalize(value);if(!target)return;
      const p=current();
      if(record&&p.url)p.back.push(p.url);
      if(record)p.forward=[];
      p.url=target;
      try{p.label=new URL(target).hostname.replace(/^www\./,'')||'New Tab'}catch(e){p.label='Search'}
      address.value=target;frame.src=target;status.textContent='Loading inside Browser OS…';
      renderTabs();row.children[0].disabled=p.back.length===0;row.children[1].disabled=p.forward.length===0;
    }
    const external=()=>{const p=current();if(p.url)window.open(p.url,'_blank','noopener,noreferrer')};
    row.querySelector('.browser-bookmark').onclick=()=>{const p=current();if(!p.url)return;let name=prompt('Bookmark name',p.label||'Website');if(name){S.bookmarks.push({name,url:p.url});save();drawBookmarks();status.textContent='Bookmark saved'}};
    drawBookmarks();
    go.onclick=()=>{
      const value=address.value.trim();const target=normalize(value);if(!target)return;
      const isSite=/^https?:\/\//i.test(value)||(/^[\w-]+(\.[\w-]+)+([/:?#].*)?$/i.test(value)&&!/\s/.test(value));
      let host='';try{host=new URL(target).hostname.replace(/^www\./,'')}catch(e){}
      const title=isSite?(host||value):'Search: '+value;
      openSite(target,title,{name:title,icon:faviconFor(target)});
      status.textContent='Opened in its own window: '+title;
    };
    address.onkeydown=e=>{if(e.key==='Enter')e.preventDefault()};
    row.children[0].onclick=()=>{const p=current();if(p.back.length){p.forward.push(p.url);p.url=p.back.pop();showPage();renderTabs()}};
    row.children[1].onclick=()=>{const p=current();if(p.forward.length){p.back.push(p.url);p.url=p.forward.pop();showPage();renderTabs()}};
    row.children[2].onclick=()=>{if(current().url){frame.src=current().url;status.textContent='Reloading…'}};
    row.querySelector('.browser-external').onclick=external;
    row.querySelector('.browser-newtab').onclick=()=>{pages.push({url:'',label:'New Tab',back:[],forward:[]});active=pages.length-1;renderTabs();showPage()};
    frame.addEventListener('load',()=>{if(current().url)status.textContent='Page loaded in Browser OS. If the page is blank, that site may block embedded browsing.'});
    pages=[{url:'',label:'New Tab',back:[],forward:[]}];
    if(url)pages[0].url=normalize(url);else if(S.homePage)pages[0].url=normalize(S.homePage);
    renderTabs();showPage();
    if(url){address.value=pages[0].url;frame.src=pages[0].url;status.textContent='Opening in Browser OS window…'}
  },app||builtin[1]);
}
/* ---------- notes app ---------- */
function openNotes(fileNode){
  openWin(fileNode?fileNode.name:'Notes',480,360,body=>{
    const row=el('div','row','<input placeholder="File name"><button>Save to Files</button>');
    const ta=el('textarea','note');ta.placeholder='Start typing…';
    body.append(row,ta);
    const nm=row.children[0],sv=row.children[1];
    nm.value=fileNode?fileNode.name:'Untitled.txt';
    if(fileNode)ta.value=fileNode.text||'';
    sv.onclick=()=>{
      const name=nm.value.trim()||'Untitled.txt';
      if(fileNode){fileNode.text=ta.value;fileNode.name=name}
      else{fileNode={id:uid(),type:'file',name,text:ta.value};S.fs.kids.push(fileNode)}
      save();sv.textContent='Saved ✓';setTimeout(()=>sv.textContent='Save to Files',1200);
    };
  },builtin[2]);
}

/* ---------- calculator ---------- */
function openCalc(){
  openWin('Calculator',280,400,body=>{
    const c=el('div','calc');const out=el('input');out.readOnly=true;c.appendChild(out);
    let exp='';
    '7 8 9 / 4 5 6 * 1 2 3 - 0 . = +'.split(' ').forEach(k=>{
      const b=el('button',/[\/*\-+=]/.test(k)?'op':'',k);
      b.onclick=()=>{
        if(k==='='){
          try{
            if(/^[\d+\-*/. ()]+$/.test(exp)){
              const r=safeCalculate(exp);
              exp=String(r);
            }
          }catch(e){exp='Error';sfx.error()}
        }else{if(exp==='Error')exp='';exp+=k}
        out.value=exp;
      };
      c.appendChild(b);
    });
    const clr=el('button','op','C');clr.style.gridColumn='1/-1';clr.onclick=()=>{exp='';out.value=''};c.appendChild(clr);
    body.appendChild(c);
  },builtin[3]);
}

/* ---------- file explorer ---------- */
function findDir(id,n=S.fs){
  if(n.id===id)return n;
  for(const k of n.kids||[]){if(k.type==='dir'){const r=findDir(id,k);if(r)return r}}
  return null;
}
const FILE_CATEGORIES={
  Documents:['txt','md','rtf','pdf','doc','docx','odt','pages','tex','log'],
  Web:['html','htm','css','js','mjs','cjs','json','xml','xhtml','php','py','rb','java','c','cpp','h','cs','go','rs','sh','bat','ps1','sql','yaml','yml','toml','ini'],
  Images:['png','jpg','jpeg','gif','webp','bmp','ico','svg','tif','tiff','avif','heic'],
  Audio:['mp3','wav','ogg','m4a','aac','flac','opus','mid','midi'],
  Video:['mp4','webm','mov','m4v','avi','mkv','mpeg','mpg','3gp'],
  Archives:['zip','tar','gz','bz2','7z','rar','xz'],
  Data:['csv','tsv','db','sqlite','parquet','geojson'],
  Fonts:['ttf','otf','woff','woff2'],
  Other:['bin','dat','iso','exe','dll','msi','app','dmg']
};
function extensionOf(name){const i=String(name).lastIndexOf('.');return i>0?name.slice(i+1).toLowerCase():''}
function fileKind(name){
  const ext=extensionOf(name);
  for(const [kind,extensions] of Object.entries(FILE_CATEGORIES))if(extensions.includes(ext))return kind;
  return 'Other';
}
function mimeForExtension(ext){
  return ({
    txt:'text/plain',md:'text/markdown',rtf:'application/rtf',pdf:'application/pdf',
    html:'text/html',htm:'text/html',css:'text/css',js:'text/javascript',mjs:'text/javascript',
    json:'application/json',xml:'application/xml',svg:'image/svg+xml',csv:'text/csv',
    png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',webp:'image/webp',
    bmp:'image/bmp',ico:'image/x-icon',mp3:'audio/mpeg',wav:'audio/wav',ogg:'audio/ogg',
    m4a:'audio/mp4',mp4:'video/mp4',webm:'video/webm',mov:'video/quicktime',
    zip:'application/zip',wasm:'application/wasm'
  })[ext]||'application/octet-stream';
}
function fileIcon(node){
  if(node.type==='dir')return '📁';
  const kind=fileKind(node.name);
  return ({Documents:'📄',Web:'🌐',Images:'🖼️',Audio:'🎵',Video:'🎬',Archives:'🗜️',Data:'📊',Fonts:'🔤',Other:'📦'})[kind]||'📄';
}
function createFileIn(dir,name,content='',mime){
  const node={id:uid(),type:'file',name,text:typeof content==='string'?content:'',mime:mime||mimeForExtension(extensionOf(name))};
  dir.kids.push(node);save();return node;
}
function exportNode(node){
  let blob;
  if(node.data && typeof node.data==='string' && node.data.startsWith('data:')){
    const parts=node.data.split(','),meta=parts[0],raw=atob(parts[1]||''),arr=new Uint8Array(raw.length);
    for(let i=0;i<raw.length;i++)arr[i]=raw.charCodeAt(i);
    blob=new Blob([arr],{type:node.mime||mimeForExtension(extensionOf(node.name))});
  }else blob=new Blob([node.text||''],{type:node.mime||mimeForExtension(extensionOf(node.name))});
  downloadBlob(node.name,blob);
}
function openFiles(startId){
  openWin('File Explorer',900,590,body=>{
    let trail=(startId&&pathTo(startId))||[S.fs.id],selected=null,clipboard=null,view=S.fileView||'grid',sort='name',filter='';
    const toolbar=el('div','row explorer-toolbar',`
      <button data-act="back" title="Back">←</button><button data-act="up" title="Up">⬆</button><button data-act="refresh" title="Refresh">↻</button>
      <button data-act="newfolder">＋ Folder</button><button data-act="newfile">＋ File</button><button data-act="import">Import</button>
      <input class="file-path" readonly aria-label="Current folder path">
      <input class="file-search" placeholder="Search this folder…" aria-label="Search files">
      <select class="file-sort" title="Sort files"><option value="name">Name</option><option value="type">Type</option><option value="date">Newest</option></select>
      <button data-act="view" title="Change view">☷</button><input type="file" class="file-import" multiple style="display:none">
    `);
    const content=el('div','explorer-layout');
    const sidebar=el('aside','explorer-sidebar');
    const main=el('section','explorer-main');
    const crumb=el('div','explorer-crumb');
    const list=el('div','files explorer-files');
    const status=el('div','explorer-status');
    main.append(crumb,list,status);content.append(sidebar,main);body.append(toolbar,content);
    const cur=()=>findDir(trail[trail.length-1])||S.fs;
    const path=()=>trail.map(id=>findDir(id)?.name||'').join('  ›  ');
    const refreshPath=()=>toolbar.querySelector('.file-path').value=path();
    const allNodes=(dir=S.fs,out=[])=>{(dir.kids||[]).forEach(k=>{out.push(k);if(k.type==='dir')allNodes(k,out)});return out};
    function findParent(id,n=S.fs){for(const k of n.kids||[]){if(k.id===id)return n;if(k.type==='dir'){const r=findParent(id,k);if(r)return r}}return null}
    function select(node,elNode){selected=node;list.querySelectorAll('.file').forEach(x=>x.classList.remove('selected'));if(elNode)elNode.classList.add('selected');updateStatus()}
    function updateStatus(){const items=cur().kids||[];status.textContent=(items.length+' item'+(items.length===1?'':'s'))+(selected?' · Selected: '+selected.name:'')+(clipboard?' · '+(clipboard.mode==='cut'?'Cut':'Copied')+': '+clipboard.node.name:'')}
    function showCategory(kind){trail=[S.fs.id];filter='';list.innerHTML='';selected=null;const nodes=allNodes().filter(k=>k.type==='file'&&fileKind(k.name)===kind);nodes.forEach(addFileItem);if(!nodes.length)list.innerHTML='<div class="emptyhint">No '+kind.toLowerCase()+' files yet.</div>';toolbar.querySelector('.file-path').value=kind;crumb.textContent='This PC  ›  '+kind;updateStatus()}
    function showAllFiles(){trail=[S.fs.id];list.innerHTML='';selected=null;const nodes=allNodes().filter(k=>k.type==='file');nodes.forEach(addFileItem);if(!nodes.length)list.innerHTML='<div class="emptyhint">No files yet.</div>';toolbar.querySelector('.file-path').value='All files';crumb.textContent='This PC  ›  All files';updateStatus()}
    function renderSidebar(){
      sidebar.innerHTML='<div class="explorer-side-heading">Quick access</div>';
      [['🏠','Home',()=>{trail=[S.fs.id];filter='';render()}],['🖥️','Desktop',()=>{const d=deskDir();trail=[S.fs.id,d.id];render()}],['📄','Documents',()=>showCategory('Documents')],['🖼️','Pictures',()=>showCategory('Images')],['🎵','Music',()=>showCategory('Audio')],['🎬','Videos',()=>showCategory('Video')],['🗜️','Archives',()=>showCategory('Archives')],['⬇️','All files',showAllFiles]].forEach(([ic,label,fn])=>{const b=el('button','sideitem','<span>'+ic+'</span><span>'+label+'</span>');b.onclick=fn;sidebar.appendChild(b)});
      sidebar.appendChild(el('div','explorer-side-heading','This PC'));
      [['💾','Browser OS storage',()=>{trail=[S.fs.id];render()}]].forEach(([ic,label,fn])=>{const b=el('button','sideitem','<span>'+ic+'</span><span>'+label+'</span>');b.onclick=fn;sidebar.appendChild(b)});
    }
    function properties(k){
      const parent=findParent(k.id),kind=k.type==='dir'?'Folder':fileKind(k.name),size=k.type==='dir'?allNodes(k,[]).length+' items':(k.size||new Blob([k.text||'']).size)+' bytes';
      openWin('Properties — '+k.name,390,330,(b,close)=>{b.appendChild(el('div','file-properties',`<div class="prop-icon">${fileIcon(k)}</div><h3>${esc(k.name)}</h3><div class="prop-grid"><span>Type</span><b>${esc(kind)}</b><span>Location</span><b>${esc(parent?pathTo(parent.id)?.map(id=>findDir(id)?.name||'').join(' › '):'Unknown')}</b><span>Size</span><b>${esc(size)}</b><span>Item ID</span><b>${esc(k.id)}</b></div><button class="btn" id="propclose">Close</button>`));b.querySelector('#propclose').onclick=close});
    }
    function pasteInto(dir){
      if(!clipboard){alert('Nothing to paste. Use Copy or Cut on a file first.');return}
      const {node,mode}=clipboard;
      if(node===dir||node.type==='dir'&&pathTo(dir.id)?.includes(node.id)){alert('You cannot paste a folder into itself or one of its subfolders.');return}
      if(mode==='cut'){
        const old=findParent(node.id);if(!old)return;
        old.kids=old.kids.filter(x=>x!==node);dir.kids=dir.kids||[];dir.kids.push(node);
      }else{
        const clone=JSON.parse(JSON.stringify(node));const rekey=n=>{n.id=uid();(n.kids||[]).forEach(rekey)};rekey(clone);dir.kids=dir.kids||[];dir.kids.push(clone);
      }
      clipboard=null;save();render();
    }
    function addFileItem(k){
      if(filter&&!k.name.toLowerCase().includes(filter.toLowerCase()))return;
      const shownName=S.showExtensions===false&&k.type==='file'?k.name.replace(/\.[^.]+$/,''):k.name;
      const f=el('div','file '+(view==='list'?'file-list':''),`<div class="emoji">${fileIcon(k)}</div><div class="filename">${esc(shownName)}</div><small>${k.type==='dir'?'File folder':fileKind(k.name)}</small>`);
      f.tabIndex=0;f.onclick=()=>select(k,f);f.ondblclick=()=>{if(k.type==='dir'){trail.push(k.id);filter='';render()}else openFileNode(k)};
      f.oncontextmenu=e=>{e.preventDefault();e.stopPropagation();select(k,f);menu(e.clientX,e.clientY,[
        ['Open',()=>k.type==='dir'?(trail.push(k.id),render()):openFileNode(k)],['Cut',()=>{clipboard={node:k,mode:'cut'};updateStatus()}],['Copy',()=>{clipboard={node:k,mode:'copy'};updateStatus()}],...(k.type==='dir'?[['Paste into folder',()=>pasteInto(k)]]:[]),
        ['Rename',()=>{const nn=prompt('Rename item',k.name);if(nn&&nn.trim()){k.name=nn.trim();save();render()}}],['Duplicate',()=>{const parent=findParent(k.id)||cur(),clone=JSON.parse(JSON.stringify(k));const rekey=n=>{n.id=uid();(n.kids||[]).forEach(rekey)};rekey(clone);clone.name=k.name.replace(/(\.[^.]+)?$/,' - Copy$1');parent.kids.push(clone);save();render()}],
        ...(k.type==='file'?[['Download / Export',()=>exportNode(k)]]:[]),['Properties',()=>properties(k)],['Delete',()=>{if(S.confirmDelete===false||confirm('Delete "'+k.name+'"?')){const d=findParent(k.id);if(d){d.kids=d.kids.filter(x=>x!==k);save();render()}}}]
      ])};
      f.onkeydown=e=>{if(e.key==='Enter')f.ondblclick()};list.appendChild(f);
    }
    function render(){
      const d=cur();selected=null;list.innerHTML='';list.classList.toggle('list-view',view==='list');refreshPath();renderSidebar();crumb.textContent='This PC  ›  '+path();
      const nodes=(d.kids||[]).filter(k=>!filter||k.name.toLowerCase().includes(filter.toLowerCase())).slice();
      nodes.sort((a,b)=>{if(a.type!==b.type)return a.type==='dir'?-1:1;const av=sort==='type'?fileKind(a.name):sort==='date'?(a.modified||0):a.name.toLowerCase(),bv=sort==='type'?fileKind(b.name):sort==='date'?(b.modified||0):b.name.toLowerCase();return sort==='date'?bv-av:String(av).localeCompare(String(bv))});
      nodes.forEach(addFileItem);
      if(!nodes.length)list.innerHTML='<div class="emptyhint">'+(filter?'No matching items.':'This folder is empty. Use New folder, New file, or Import.')+'</div>';
      updateStatus();
    }
    const actions={
      back:()=>{if(trail.length>1){trail.pop();render()}},up:()=>{if(trail.length>1){trail.pop();render()}},refresh:render,
      newfolder:()=>{const name=prompt('Folder name','New folder');if(name){cur().kids.push({id:uid(),type:'dir',name,kids:[]});save();render()}},
      newfile:()=>{const name=prompt('New file name','New text document.txt');if(name){const n=createFileIn(cur(),name,'');render();openFileNode(n)}},
      import:()=>toolbar.querySelector('.file-import').click(),
      view:()=>{view=view==='grid'?'list':'grid';S.fileView=view;save();render()}
    };
    toolbar.querySelectorAll('[data-act]').forEach(b=>b.onclick=actions[b.dataset.act]);
    toolbar.querySelector('.file-search').oninput=e=>{filter=e.target.value;render()};
    toolbar.querySelector('.file-sort').value=sort;toolbar.querySelector('.file-sort').onchange=e=>{sort=e.target.value;render()};
    const importer=toolbar.querySelector('.file-import');
    importer.onchange=()=>{[...importer.files].forEach(file=>{const reader=new FileReader();reader.onload=()=>{const result=reader.result;const n={id:uid(),type:'file',name:file.name,text:typeof result==='string'&&file.type.startsWith('text/')?result:'',data:typeof result==='string'?result:'',mime:file.type||mimeForExtension(extensionOf(file.name)),size:file.size,modified:Date.now()};cur().kids.push(n);save();render()};if(file.type.startsWith('text/')||/\.(txt|md|rtf|html?|css|js|mjs|json|xml|csv|tsv|py|java|c|cpp|h|cs|go|rs|sh|bat|ps1|sql|yaml|yml|toml|ini|svg)$/i.test(file.name))reader.readAsText(file);else reader.readAsDataURL(file)});importer.value=''};
    list.oncontextmenu=e=>{if(e.target===list||e.target.classList.contains('emptyhint')){e.preventDefault();menu(e.clientX,e.clientY,[['New folder',actions.newfolder],['New file',actions.newfile],['Paste',()=>pasteInto(cur())],['Import files',actions.import],['Refresh',render]])}};
    body.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='c'&&selected)clipboard={node:selected,mode:'copy'};if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='x'&&selected)clipboard={node:selected,mode:'cut'};if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='v')pasteInto(cur());if(e.key==='Delete'&&selected){const k=selected,d=findParent(k.id);if(d&&(S.confirmDelete===false||confirm('Delete "'+k.name+'"?'))){d.kids=d.kids.filter(x=>x!==k);save();render()}}});
    render();
  },builtin[0]);
}

/* ---------- settings ---------- */
/* ---------- Settings: grouped like Windows ---------- */
const SETTINGS_PAGES=[
  ['system','🖥️','System'],
  ['personal','🎨','Personalization'],
  ['apps','🧩','Apps'],
  ['accounts','👤','Accounts'],
  ['time','🕒','Time & language'],
  ['browser','🌐','Browser & search'],
  ['access','♿','Accessibility'],
  ['privacy','🔒','Privacy']
];
function openSettings(start){
  openWin('Settings',800,560,body=>{
    const wrap=el('div','set-wrap'),nav=el('div','set-nav'),pane=el('div','set set-pane');
    wrap.append(nav,pane);body.appendChild(wrap);
    const add=n=>{pane.appendChild(n);return n};
    const h=(t,sub)=>{add(el('h2','',esc(t)));if(sub)add(el('div','set-sub',esc(sub)))};
    const sec=t=>add(el('h4','',esc(t)));
    const note=t=>add(el('div','set-note',esc(t)));
    const field=(label,input)=>{const l=el('label','',esc(label));l.appendChild(input);return add(l)};
    const sel=(opts,val,on)=>{const s=el('select');opts.forEach(([v,t])=>{const o=el('option','',esc(t));o.value=v;s.appendChild(o)});s.value=val;s.onchange=()=>on(s.value);return s};
    const txt=(val,on,ph,max)=>{const i=el('input');i.value=val||'';if(ph)i.placeholder=ph;if(max)i.maxLength=max;i.onchange=()=>on(i.value);return i};
    const chk=(label,val,on)=>{const l=el('label','chk');const c=el('input');c.type='checkbox';c.checked=!!val;c.onchange=()=>on(c.checked);l.append(c,document.createTextNode(label));return l};
    const btn=(label,on,primary)=>{const b=el('button','btn'+(primary?'':' alt'),esc(label));b.onclick=()=>on();return b};
    const actions=(...b)=>{const r=add(el('div','set-actions'));r.append(...b);return r};
    const pick=(input,on)=>{input.onchange=()=>{const f=input.files[0];if(f)readFile(f,on)};return input};
    const fileIn=()=>{const i=el('input');i.type='file';i.accept='image/*';return i};

    const pages={
      system(){
        h('System','Sound, startup and device details.');
        sec('Sound and startup');
        add(chk('Sound effects',S.sound,v=>{S.sound=v;save();if(v)sfx.chime()}));
        field('Startup screen text',txt(S.bootText,v=>{S.bootText=v;save()}));
        sec('Device');
        field('Device name',txt(S.deviceName||'BROWSER-OS',v=>{S.deviceName=v.trim()||'BROWSER-OS';save()},'',32));
        actions(btn('System information',openSystemInfo),btn('Task Manager',openTaskManager),btn('Lock now',lockNow));
        sec('About');
        note('Browser OS version '+VERSION+'. Everything you change here is saved automatically.');
      },

      personal(){
        h('Personalization','Make Browser OS look the way you like.');
        sec('Background');
        const presets={blue:'#1e3a5f',aurora:'linear-gradient(135deg,#102a43,#245b68,#5b3b73)',sunset:'linear-gradient(135deg,#3b1d5a,#d45d48,#f2b36d)',dark:'#101827',mint:'linear-gradient(135deg,#123c3a,#2c786b,#a5c9a5)'};
        field('Preset wallpaper',sel([['','Choose a wallpaper…'],['blue','Windows Blue'],['aurora','Aurora'],['sunset','Sunset'],['dark','Midnight'],['mint','Mint']],'',v=>{
          const p=presets[v];if(!p)return;
          S.bgImg='';
          if(p.startsWith('linear-gradient')){S.bgGrad=p}else{S.bg=p;S.bgGrad=''}
          applyLook();save();
        }));
        const bg=el('input');bg.type='color';bg.value=(S.bg&&S.bg.startsWith('#'))?S.bg:'#1e3a5f';
        bg.oninput=()=>{S.bg=bg.value;S.bgGrad='';applyLook()};bg.onchange=()=>save();
        field('Background color',bg);
        field('Background image',pick(fileIn(),d=>{S.bgImg=d;applyLook();save()}));
        actions(btn('Remove background image',()=>{S.bgImg='';applyLook();save()}));
        sec('Colors');
        const ac=el('input');ac.type='color';ac.value=S.accent||'#2787d8';
        ac.oninput=()=>{S.accent=ac.value;applyLook()};ac.onchange=()=>save();
        field('Accent color',ac);
        field('Color theme',sel([['dark','Dark'],['light','Light']],S.theme||'dark',v=>{S.theme=v;applyLook();save()}));
        sec('Mouse cursor');
        field('Style',sel([['default','Default'],['crosshair','Crosshair'],['pointer','Hand'],['cell','Cell'],['help','Help']],S.cursor||'default',v=>{S.cursor=v;S.cursorImg='';applyLook();save()}));
        field('Custom image (small PNG, 32x32 works best)',pick(fileIn(),d=>{S.cursorImg=d;applyLook();save()}));
        actions(btn('Remove custom cursor',()=>{S.cursorImg='';applyLook();save()}));
      },

      apps(){
        h('Apps','Choose where your apps show up.');
        sec('Desktop');
        note('Checked apps have an icon on the desktop. Every app is always available in the Start menu.');
        const dc=add(el('div','set-checks'));
        allApps().forEach(a=>dc.appendChild(chk(a.name,(S.deskApps||[]).includes(a.id),v=>setDesk(a.id,v))));
        actions(btn('Reset desktop icon positions',()=>{S.iconPos={};save();renderIcons()}));
        sec('Taskbar');
        note('Checked apps are pinned to the taskbar.');
        const pc=add(el('div','set-checks'));
        allApps().forEach(a=>pc.appendChild(chk(a.name,isPinned(a.id),v=>v?pinApp(a.id):unpinApp(a.id))));
        sec('Websites as apps');
        if(!S.apps.length)note('You have not added any website apps yet.');
        S.apps.forEach(a=>{
          const r=add(el('div','set-list-row'));
          r.appendChild(el('span','',esc(a.name)+' <small style="color:var(--muted)">'+esc(a.url)+'</small>'));
          r.appendChild(btn('Remove',()=>{uninstallApp(a.id);show('apps')}));
        });
        actions(btn('Add a website app',()=>addAppDialog(()=>show('apps')),true));
        sec('File Explorer');
        field('Default layout',sel([['grid','Icons'],['list','List']],S.fileView||'grid',v=>{S.fileView=v;save()}));
        add(chk('Show file extensions',S.showExtensions!==false,v=>{S.showExtensions=v;save()}));
        add(chk('Ask before deleting files',S.confirmDelete!==false,v=>{S.confirmDelete=v;save()}));
      },

      accounts(){
        h('Accounts','Your profile and sign-in.');
        sec('Profile');
        field('Display name',txt(S.profileName||'User',v=>{S.profileName=v.trim()||'User';save();renderStart()},'',32));
        sec('Password');
        const status=note(S.pass?'A password is set. Browser OS asks for it each time it starts.':'No password is set. Browser OS opens without asking for one.');
        const p1=el('input'),p2=el('input');
        [p1,p2].forEach(i=>{i.type='password';i.autocomplete='new-password'});
        field('New password',p1);field('Confirm new password',p2);
        const err=add(el('small','set-note'));
        actions(
          btn('Set password',()=>{
            if(!p1.value){err.textContent='Type a password first.';sfx.error();return}
            if(p1.value!==p2.value){err.textContent='The passwords do not match.';sfx.error();return}
            if(p1.value.length<4){err.textContent='Use at least 4 characters.';sfx.error();return}
            S.pass=p1.value;save();p1.value='';p2.value='';
            err.textContent='Password updated.';status.textContent='A password is set. Browser OS asks for it each time it starts.';
          },true),
          btn('Remove password',()=>{
            if(!S.pass){err.textContent='There is no password to remove.';return}
            if(!confirm('Remove the password? Browser OS will open without asking for one.'))return;
            S.pass='';save();err.textContent='Password removed.';status.textContent='No password is set. Browser OS opens without asking for one.';
          })
        );
      },

      time(){
        h('Time & language','Clock and regional preferences.');
        sec('Taskbar clock');
        field('Time format',sel([['12','12-hour clock'],['24','24-hour clock']],S.timeFormat||'12',v=>{S.timeFormat=v;save();tick()}));
        add(chk('Show seconds',S.showSeconds,v=>{S.showSeconds=v;save();tick()}));
        add(chk('Show the date under the time',S.showDate!==false,v=>{S.showDate=v;save();tick()}));
        sec('Region and language');
        const L=(list,key,def)=>sel(list.map(x=>[x,x]),S[key]||def,v=>{S[key]=v;save()});
        field('Country or region',L(['United States','Canada','United Kingdom','Australia','India','Germany','France','Japan','Other'],'region','United States'));
        field('Display language',L(['English (United States)','English (United Kingdom)','Spanish','French','German','Japanese','Portuguese','Other'],'language','English (United States)'));
        field('Keyboard layout',L(['US','United Kingdom','Canadian Multilingual','German','French','Japanese'],'keyboard','US'));
        note('Region, language and keyboard are saved to your profile. They do not translate Browser OS yet.');
      },

      browser(){
        h('Browser & search','Choose how the Browser app searches and where it starts.');
        sec('Search engine');
        const opts=Object.entries(ENGINES).map(([k,v])=>[k,v[0]]).concat([['custom','Custom…']]);
        const es=sel(opts,S.searchEngine||'google',v=>{S.searchEngine=v;save()});
        field('Search with',es);
        const msg=el('small','set-note');
        field('Custom search address (put %s where the search words go)',txt(S.customSearch||'',v=>{
          v=v.trim();
          if(!v){S.customSearch='';if(S.searchEngine==='custom'){S.searchEngine='google';es.value='google'}save();msg.textContent='Custom search removed.';return}
          if(!/^https?:\/\//i.test(v)||!v.includes('%s')){msg.textContent='Start with https:// and include %s, for example https://example.com/search?q=%s';sfx.error();return}
          S.customSearch=v;S.searchEngine='custom';es.value='custom';save();msg.textContent='Saved. The Browser now searches with your custom address.';
        },'https://example.com/search?q=%s'));
        add(msg);
        note('Some websites refuse to load inside another page. If a search site will not show in the Browser window, use the ↗ button to open that page in Chrome.');
        sec('Start page');
        field('Browser home page',txt(S.homePage||'',v=>{S.homePage=v.trim();save()},'https://example.com'));
        sec('Bookmarks');
        const n=(S.bookmarks||[]).length;
        note(n+(n===1?' bookmark saved.':' bookmarks saved.'));
        actions(btn('Clear all bookmarks',()=>{if(!(S.bookmarks||[]).length)return;if(confirm('Delete all bookmarks?')){S.bookmarks=[];save();show('browser')}}));
      },

      access(){
        h('Accessibility','Make Browser OS easier to see and use.');
        field('Interface size',sel([['normal','Normal'],['large','Large'],['compact','Compact']],S.uiSize||'normal',v=>{S.uiSize=v;applyLook();save()}));
        add(chk('Reduce motion',S.reduceMotion,v=>{S.reduceMotion=v;applyLook();save()}));
      },

      privacy(){
        h('Privacy','Browser OS keeps its data in Chrome on this device.');
        add(chk('Allow location access when a feature asks for it',S.locationConsent,v=>{S.locationConsent=v;save()}));
        add(chk('Keep optional usage diagnostics (stored locally only)',S.diagnostics,v=>{S.diagnostics=v;save()}));
      }
    };

    const show=key=>{
      pane.innerHTML='';pane.scrollTop=0;
      nav.querySelectorAll('button').forEach(b=>b.classList.toggle('active',b.dataset.k===key));
      pages[key]();
    };
    SETTINGS_PAGES.forEach(([k,ic,t])=>{
      const b=el('button','','<span>'+ic+'</span>'+esc(t));b.dataset.k=k;b.onclick=()=>show(k);nav.appendChild(b);
    });
    show(typeof start==='string'&&pages[start]?start:'system');
  },builtin[4]);
}


/* ---------- file types and additional built-in apps ---------- */
function guessMime(name){
  const e=(String(name).split('.').pop()||'').toLowerCase();
  return ({txt:'text/plain',md:'text/markdown',html:'text/html',htm:'text/html',css:'text/css',js:'text/javascript',json:'application/json',csv:'text/csv',xml:'application/xml',svg:'image/svg+xml',png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',webp:'image/webp',mp3:'audio/mpeg',wav:'audio/wav',ogg:'audio/ogg',mp4:'video/mp4',webm:'video/webm',pdf:'application/pdf'})[e]||'application/octet-stream';
}
function createTypedFile(ext,dir=S.fs,refresh){
  const name=prompt('File name','New file.'+ext);
  if(!name)return;
  (dir.kids||(dir.kids=[])).push({id:uid(),type:'file',name,text:'',mime:guessMime(name)});
  save();
  if(refresh)refresh();
}
function downloadBlob(name,blob){
  const a=document.createElement('a'),u=URL.createObjectURL(blob);
  a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1500);
}
function openFileNode(node){
  const ext=extensionOf(node.name),mime=node.mime||mimeForExtension(ext),data=node.data||'';
  if(node.data && /^image\//.test(mime)){
    openWin(node.name,700,500,b=>{const im=el('img');im.src=data;im.style.cssText='max-width:100%;max-height:100%;object-fit:contain;margin:auto';b.appendChild(im)});
  }else if(['mp3','wav','ogg','m4a','aac','flac','opus'].includes(ext)){
    openWin(node.name,560,220,b=>{const m=el('audio');m.controls=true;m.style.cssText='width:calc(100% - 32px);margin:30px 16px';if(data)m.src=data;b.appendChild(m)});
  }else if(['mp4','webm','mov','m4v','ogv'].includes(ext)){
    openWin(node.name,700,480,b=>{const m=el('video');m.controls=true;m.style.cssText='max-width:100%;max-height:100%;margin:auto';if(data)m.src=data;b.appendChild(m)});
  }else if(ext==='pdf' && data){
    openWin(node.name,760,560,b=>{const fr=el('iframe');fr.src=data;b.appendChild(fr)});
  }else if(['txt','md','rtf','html','htm','css','js','mjs','json','xml','csv','tsv','svg','log','ini','py','java','c','cpp','h','cs','go','rs','sh','bat','ps1','sql','yaml','yml','toml'].includes(ext) || !ext){
    openNotes(node);
  }else{
    openWin(node.name,460,260,b=>{
      const info=el('div','set',`<h3>${esc(node.name)}</h3><p>File type: ${esc(mime)}</p><p>Category: ${esc(fileKind(node.name))}</p><p>This format can be stored, renamed, imported, and exported here. A compatible editor or viewer may be needed to open it.</p><button class="btn" id="filedownload">Download file</button>`);
      b.appendChild(info);info.querySelector('#filedownload').onclick=()=>exportNode(node);
    });
  }
}
function safeCalculate(source){
  const s=source.replace(/\s+/g,'');
  if(!/^[0-9+\-*/().%]+$/.test(s))throw Error('Invalid expression');
  const tokens=s.match(/\d*\.?\d+|[()+\-*/%]/g)||[];
  if(tokens.join('')!==s)throw Error('Invalid expression');
  let p=0;
  function primary(){const t=tokens[p++];if(t==='('){const v=expr();if(tokens[p++]!==')')throw Error('Missing )');return v}if(t==='-')return -primary();if(t==='+')return primary();const n=Number(t);if(!Number.isFinite(n))throw Error('Invalid number');return n}
  function term(){let v=primary();while(['*','/','%'].includes(tokens[p])){const op=tokens[p++],n=primary();v=op==='*'?v*n:op==='/'?v/n:v%n}return v}
  function expr(){let v=term();while(['+','-'].includes(tokens[p])){const op=tokens[p++],n=term();v=op==='+'?v+n:v-n}return v}
  const result=expr();if(p!==tokens.length||!Number.isFinite(result))throw Error('Invalid calculation');return result;
}
function openPaint(){
  openWin('Paint',900,650,body=>{
    const tools=el('div','paint-tools',`<label>Tool<select id="ptool"><option value="pencil">Pencil</option><option value="eraser">Eraser</option><option value="line">Line</option><option value="rect">Rectangle</option><option value="fillrect">Filled rectangle</option><option value="ellipse">Ellipse</option><option value="text">Text</option></select></label><label>Color <input type="color" value="#202020" id="paintcolor"></label><label>Size <input type="range" min="1" max="40" value="4" id="paintsize"></label><button id="paintundo">Undo</button><button id="paintclear">Clear</button><button id="paintopen">Open image</button><button id="paintsave">Save PNG</button><input id="paintfile" type="file" accept="image/*" hidden>`);
    const canvas=el('canvas','paintcanvas');canvas.width=1200;canvas.height=720;
    const wrap=el('div','paintwrap');wrap.appendChild(canvas);body.append(tools,wrap);
    const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);
    let down=false,start=null,snapshot=null,undo=[];
    const point=e=>{const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)*canvas.width/r.width,y:(e.clientY-r.top)*canvas.height/r.height}};
    const saveUndo=()=>{try{undo.push(ctx.getImageData(0,0,canvas.width,canvas.height));if(undo.length>15)undo.shift()}catch(e){}};
    const drawShape=(p)=>{const tool=tools.querySelector('#ptool').value;ctx.putImageData(snapshot,0,0);ctx.strokeStyle=tools.querySelector('#paintcolor').value;ctx.fillStyle=ctx.strokeStyle;ctx.lineWidth=+tools.querySelector('#paintsize').value;ctx.lineCap='round';if(tool==='line'){ctx.beginPath();ctx.moveTo(start.x,start.y);ctx.lineTo(p.x,p.y);ctx.stroke()}if(tool==='rect'||tool==='fillrect'){const x=Math.min(start.x,p.x),y=Math.min(start.y,p.y),w=Math.abs(p.x-start.x),h=Math.abs(p.y-start.y);tool==='rect'?ctx.strokeRect(x,y,w,h):ctx.fillRect(x,y,w,h)}if(tool==='ellipse'){ctx.beginPath();ctx.ellipse((start.x+p.x)/2,(start.y+p.y)/2,Math.abs(p.x-start.x)/2,Math.abs(p.y-start.y)/2,0,0,Math.PI*2);ctx.stroke()}};
    canvas.onpointerdown=e=>{down=true;start=point(e);saveUndo();snapshot=ctx.getImageData(0,0,canvas.width,canvas.height);canvas.setPointerCapture(e.pointerId);const tool=tools.querySelector('#ptool').value;if(tool==='text'){const t=prompt('Text to place:');if(t){ctx.fillStyle=tools.querySelector('#paintcolor').value;ctx.font=(+tools.querySelector('#paintsize').value*5+12)+'px Segoe UI';ctx.fillText(t,start.x,start.y)}down=false}else if(tool==='pencil'||tool==='eraser'){ctx.beginPath();ctx.moveTo(start.x,start.y)}};
    canvas.onpointermove=e=>{if(!down)return;const p=point(e),tool=tools.querySelector('#ptool').value;if(tool==='pencil'||tool==='eraser'){ctx.strokeStyle=tool==='eraser'?'#fff':tools.querySelector('#paintcolor').value;ctx.lineWidth=tool==='eraser'?Math.max(12,+tools.querySelector('#paintsize').value*4):+tools.querySelector('#paintsize').value;ctx.lineTo(p.x,p.y);ctx.stroke()}else drawShape(p)};
    canvas.onpointerup=canvas.onpointercancel=e=>{if(down&&['line','rect','fillrect','ellipse'].includes(tools.querySelector('#ptool').value))drawShape(point(e));down=false};
    tools.querySelector('#paintundo').onclick=()=>{const d=undo.pop();if(d)ctx.putImageData(d,0,0)};
    tools.querySelector('#paintclear').onclick=()=>{saveUndo();ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height)};
    tools.querySelector('#paintsave').onclick=()=>canvas.toBlob(b=>downloadBlob('Painting.png',b),'image/png');
    tools.querySelector('#paintopen').onclick=()=>tools.querySelector('#paintfile').click();
    tools.querySelector('#paintfile').onchange=e=>{const f=e.target.files[0];if(f){const im=new Image();im.onload=()=>{saveUndo();ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(im,0,0,canvas.width,canvas.height)};im.src=URL.createObjectURL(f)}};
  },{emoji:'🎨'});
}

function openCalendar(){
  openWin('Calendar',420,430,body=>{
    const now=new Date(),head=el('div','calendarhead'),grid=el('div','calgrid');
    let shown=new Date(now.getFullYear(),now.getMonth(),1);
    function draw(){head.innerHTML='';const prev=el('button','btn alt','‹'),next=el('button','btn alt','›'),label=el('b','',shown.toLocaleDateString([], {month:'long',year:'numeric'}));prev.onclick=()=>{shown.setMonth(shown.getMonth()-1);draw()};next.onclick=()=>{shown.setMonth(shown.getMonth()+1);draw()};head.append(prev,label,next);grid.innerHTML='';['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].forEach(x=>grid.appendChild(el('div','calday',x)));const first=shown.getDay(),days=new Date(shown.getFullYear(),shown.getMonth()+1,0).getDate();for(let i=0;i<first;i++)grid.appendChild(el('div','calblank'));for(let d=1;d<=days;d++){const b=el('button','caldate',String(d));if(d===now.getDate()&&shown.getMonth()===now.getMonth()&&shown.getFullYear()===now.getFullYear())b.classList.add('today');b.onclick=()=>{body.querySelector('.calchosen').textContent=new Date(shown.getFullYear(),shown.getMonth(),d).toDateString()};grid.appendChild(b)}}
    const chosen=el('div','calchosen',now.toDateString());body.append(head,grid,chosen);draw();
  },{emoji:'📅'});
}
function openClock(){
  openWin('Clock',360,260,body=>{
    const clock=el('div','bigclock'),date=el('div','clockdate'),sw=el('div','stopwatch','00:00.0'),controls=el('div','row','<button id="swstart">Start</button><button id="swreset">Reset</button>');
    body.append(clock,date,sw,controls);
    const update=()=>{const d=new Date();clock.textContent=d.toLocaleTimeString();date.textContent=d.toLocaleDateString([], {weekday:'long',year:'numeric',month:'long',day:'numeric'})};update();const timer=setInterval(update,1000);
    let start=0,elapsed=0,run=false,interval=null;
    controls.querySelector('#swstart').onclick=()=>{run=!run;const b=controls.querySelector('#swstart');b.textContent=run?'Pause':'Start';if(run){start=Date.now()-elapsed;interval=setInterval(()=>{elapsed=Date.now()-start;sw.textContent=(elapsed/60000|0).toString().padStart(2,'0')+':'+((elapsed/1000|0)%60).toString().padStart(2,'0')+'.'+(elapsed%1000/100|0)},100)}else clearInterval(interval)};
    controls.querySelector('#swreset').onclick=()=>{run=false;clearInterval(interval);elapsed=0;sw.textContent='00:00.0';controls.querySelector('#swstart').textContent='Start'};
  },{emoji:'⏰'});
}
function openMedia(){
  openWin('Media Player',560,360,body=>{
    const row=el('div','row','<input type="file" id="mediafile" accept="audio/*,video/*">');
    const stage=el('div','mediastage','<div class="mediawelcome">♫ Choose an audio or video file to play</div>');
    body.append(row,stage);
    row.querySelector('input').onchange=e=>{const f=e.target.files[0];if(!f)return;stage.innerHTML='';const m=el(f.type.startsWith('video/')?'video':'audio');m.controls=true;m.autoplay=true;m.src=URL.createObjectURL(f);stage.appendChild(m)};
  },{emoji:'🎵'});
}
function openTerminal(){
  openWin('Terminal',680,440,body=>{
    const out=el('div','terminalout','Browser OS Terminal<br>Type <b>help</b> to see commands.');
    const row=el('div','terminalrow','<span>&gt;</span><input autocomplete="off" spellcheck="false">');body.append(out,row);
    const input=row.querySelector('input');
    const print=(v)=>{out.innerHTML+='<div>'+v+'</div>';out.scrollTop=out.scrollHeight};
    function command(){
      const raw=input.value.trim(),parts=raw.match(/(?:[^\s"]+|"[^"]*")+/g)||[],cmd=(parts.shift()||'').toLowerCase(),arg=parts.join(' ').replace(/^"|"$/g,''),safe=esc(arg);let result='';
      const list=(dir=S.fs)=>dir.kids||[];
      if(cmd==='help')result='help · cls/clear · date · time · ver · whoami · hostname · pwd · ls/dir · tree · apps · open APP · mkdir NAME · touch FILE · rm NAME · rename OLD NEW · echo TEXT · calc EXPR · theme · sound on|off · todo · notes · browser URL';
      else if(cmd==='date')result=new Date().toDateString();
      else if(cmd==='time')result=new Date().toLocaleTimeString();
      else if(cmd==='ver')result='Browser OS 2.5.0';
      else if(cmd==='whoami')result='local-user';
      else if(cmd==='hostname')result='BROWSER-OS';
      else if(cmd==='pwd')result='/';
      else if(cmd==='ls'||cmd==='dir')result=list().map(x=>esc(x.name)+(x.type==='dir'?'/':'')).join('<br>')||'(empty)';
      else if(cmd==='tree')result='Root<br>'+list().map(x=>'├─ '+esc(x.name)).join('<br>');
      else if(cmd==='apps')result=builtin.map(x=>esc(x.name)).join(' · ');
      else if(cmd==='todo'){openTodo();result='Opened To Do'}
      else if(cmd==='notes'){openSticky();result='Opened Sticky Notes'}
      else if(cmd==='browser'){if(arg){const u=/^https?:\/\//i.test(arg)?arg:'https://'+arg;let h='';try{h=new URL(u).hostname.replace(/^www\./,'')}catch(e){}openSite(u,h||arg,{name:h||arg,icon:faviconFor(u)})}else openBrowser('','Browser');result='Opened Browser'}
      else if(cmd==='open'){const app=allApps().find(x=>x.name.toLowerCase()===arg.toLowerCase()||x.id===arg.toLowerCase());if(app){app.open();result='Opened '+esc(app.name)}else result='App not found: '+safe}
      else if(cmd==='mkdir'){if(!arg)result='Usage: mkdir folder-name';else{S.fs.kids.push({id:uid(),type:'dir',name:arg,kids:[]});save();result='Created folder '+safe}}
      else if(cmd==='touch'){if(!arg)result='Usage: touch filename.ext';else{createFileIn(S.fs,arg,'',guessMime(arg));result='Created '+safe}}
      else if(cmd==='rm'){const i=list().findIndex(x=>x.name===arg);if(i<0)result='Not found: '+safe;else{list().splice(i,1);save();result='Removed '+safe}}
      else if(cmd==='rename'){const old=parts[0],neu=parts[1];const f=list().find(x=>x.name===old);if(f&&neu){f.name=neu;save();result='Renamed '+esc(old)+' to '+esc(neu)}else result='Usage: rename OLD NEW'}
      else if(cmd==='echo')result=safe;
      else if(cmd==='calc'){try{result=String(safeCalculate(arg))}catch(e){result='Invalid expression'}}
      else if(cmd==='theme')result='Theme: '+esc(S.bg);
      else if(cmd==='sound'){S.sound=arg!=='off';save();result='Sound '+(S.sound?'on':'off')}
      else if(cmd==='clear'||cmd==='cls'){out.innerHTML='';input.value='';return}
      else if(cmd)result='Command not found: '+esc(cmd);
      print('<span class="terminalline">&gt; '+esc(raw)+'</span><br>'+result);input.value='';
    }
    input.onkeydown=e=>{if(e.key==='Enter')command()};
  },{emoji:'⌨️'});
}

function openTaskManager(){
  openWin('Task Manager',520,420,body=>{
    const list=el('div','taskmgrlist');body.appendChild(el('div','row','','<b>Running applications</b>'));body.appendChild(list);
    function draw(){
      list.innerHTML='';
      Object.entries(wins).forEach(([id,o])=>{
        const title=o.win.querySelector('.title')?.textContent||'Application';
        const r=el('div','taskmgrrow',`<span>▣ ${esc(title)}</span>`);
        const b=el('button','btn alt','End task');b.onclick=()=>{o.close();draw()};
        r.appendChild(b);list.appendChild(r);
      });
      Object.keys(sites).forEach(key=>{
        const r=el('div','taskmgrrow',`<span>🌐 ${esc(sites[key].task.title||'Website')}</span>`);
        const b=el('button','btn alt','End task');b.onclick=()=>{closeSite(key);setTimeout(draw,400)};
        r.appendChild(b);list.appendChild(r);
      });
      if(!list.children.length)list.textContent='No running applications';
    }
    draw();setInterval(()=>{if(list.isConnected)draw()},2000);
  },{emoji:'📊'});
}
function openPhotos(){
  openWin('Photos',600,420,body=>{
    const row=el('div','row','<input type="file" id="photosfiles" accept="image/*" multiple>'),gallery=el('div','photogallery');
    body.append(row,gallery);row.querySelector('input').onchange=e=>{[...e.target.files].forEach(f=>{const im=el('img');im.src=URL.createObjectURL(f);im.title=f.name;im.onclick=()=>{const w=openWin(f.name,700,520,b=>{const big=el('img');big.src=im.src;big.style.cssText='max-width:100%;max-height:100%;object-fit:contain;margin:auto';b.appendChild(big)},{emoji:'🖼️'})};gallery.appendChild(im)})};
  },{emoji:'🖼️'});
}
function openSetup(){
  openWin('Browser OS Setup',640,480,body=>{
    body.innerHTML=`<div class="setup-page"><div class="setup-logo">▦</div><h1>Welcome to Browser OS</h1><p>Personalize your desktop. No AI features or assistants are included.</p><label>Device name<input id="setupname" value="BROWSER-OS"></label><label>Choose a color<select id="setupcolor"><option value="#1e3a5f">Blue</option><option value="#172554">Deep blue</option><option value="#243b35">Forest</option><option value="#302044">Violet</option></select></label><label>Optional sign-in password<input id="setuppass" type="password" placeholder="Leave blank for no password"></label><label>Confirm password<input id="setupconfirm" type="password"></label><button class="btn" id="setupfinish">Finish setup</button><div id="setuperr"></div></div>`;
    body.querySelector('#setupfinish').onclick=()=>{const pw=body.querySelector('#setuppass').value;if(pw!==body.querySelector('#setupconfirm').value){body.querySelector('#setuperr').textContent='Passwords do not match.';return}S.deviceName=body.querySelector('#setupname').value||'BROWSER-OS';S.bg=body.querySelector('#setupcolor').value;S.pass=pw;save();applyLook();body.querySelector('#setuperr').textContent='Setup complete ✓';};
  },{emoji:'🪟'});
}
function openTodo(){
  openWin('To Do',520,460,body=>{
    if(!Array.isArray(S.todo))S.todo=[];
    const form=el('div','row','<input placeholder="Add a task…"><button>Add</button>');
    const list=el('div','todo-list');body.append(form,list);
    const input=form.querySelector('input');
    function draw(){list.innerHTML='';S.todo.forEach((t,i)=>{
      const line=el('div','todo-item');const cb=el('input');cb.type='checkbox';cb.checked=!!t.done;
      const label=el('span',t.done?'done':'',esc(t.text));const del=el('button','btn alt','Delete');
      cb.onchange=()=>{t.done=cb.checked;save();draw()};del.onclick=()=>{S.todo.splice(i,1);save();draw()};
      line.append(cb,label,del);list.appendChild(line);
    });if(!S.todo.length)list.innerHTML='<p class="app-empty">Your task list is empty. Add something above.</p>'}
    const add=()=>{const v=input.value.trim();if(!v)return;S.todo.push({text:v,done:false});input.value='';save();draw()};
    form.querySelector('button').onclick=add;input.onkeydown=e=>{if(e.key==='Enter')add()};draw();
  },{emoji:'☑️'});
}
function openSticky(){
  openWin('Sticky Notes',430,430,body=>{
    if(!Array.isArray(S.stickies))S.stickies=[];
    const top=el('div','row','<button class="btn" id="newsticky">＋ New note</button>');
    const list=el('div','sticky-list');body.append(top,list);
    function draw(){list.innerHTML='';S.stickies.forEach((n,i)=>{
      const card=el('div','sticky-card');const ta=el('textarea');ta.value=n.text||'';ta.placeholder='Write a note…';
      const del=el('button','btn alt','Delete');ta.oninput=()=>{n.text=ta.value;save()};del.onclick=()=>{S.stickies.splice(i,1);save();draw()};
      card.append(ta,del);list.appendChild(card);
    })}
    top.querySelector('button').onclick=()=>{S.stickies.unshift({text:''});save();draw()};draw();
  },{emoji:'🗒️'});
}
function openUnitConverter(){
  openWin('Unit Converter',430,350,body=>{
    body.innerHTML=`<div class="set"><h3>Unit Converter</h3><label>Value<input id="uv" type="number" value="1"></label><label>Convert<select id="ut"><option value="km-mi">Kilometers → Miles</option><option value="mi-km">Miles → Kilometers</option><option value="c-f">Celsius → Fahrenheit</option><option value="f-c">Fahrenheit → Celsius</option><option value="kg-lb">Kilograms → Pounds</option><option value="lb-kg">Pounds → Kilograms</option><option value="cm-in">Centimeters → Inches</option><option value="in-cm">Inches → Centimeters</option><option value="l-gal">Liters → US gallons</option><option value="gal-l">US gallons → Liters</option></select></label><h2 id="ur">1</h2></div>`;
    const calc=()=>{const v=Number(body.querySelector('#uv').value),k=body.querySelector('#ut').value;const f={'km-mi':.621371,'mi-km':1.60934,'c-f':v=>v*9/5+32,'f-c':v=>(v-32)*5/9,'kg-lb':2.20462,'lb-kg':.453592,'cm-in':.393701,'in-cm':2.54,'l-gal':.264172,'gal-l':3.78541}[k];const r=typeof f==='function'?f(v):v*f;body.querySelector('#ur').textContent=Number.isFinite(r)?Number(r.toFixed(5)).toString():'—'};
    body.querySelector('#uv').oninput=calc;body.querySelector('#ut').onchange=calc;calc();
  },{emoji:'📐'});
}
function openFocusTimer(){
  openWin('Focus Timer',360,300,body=>{
    body.innerHTML=`<div class="set"><h3>Focus session</h3><label>Minutes<input id="fm" type="number" min="1" max="180" value="25"></label><h1 id="fdisplay" style="font-size:48px;text-align:center">25:00</h1><div class="row"><button id="fstart">Start</button><button id="freset">Reset</button></div></div>`;
    let remaining=1500,interval=null;
    const display=body.querySelector('#fdisplay'),mins=body.querySelector('#fm'),start=body.querySelector('#fstart');
    const draw=()=>display.textContent=Math.floor(remaining/60).toString().padStart(2,'0')+':'+(remaining%60).toString().padStart(2,'0');
    const reset=()=>{clearInterval(interval);interval=null;remaining=Math.max(1,Math.min(180,Number(mins.value)||25))*60;draw();start.textContent='Start'};
    mins.onchange=reset;start.onclick=()=>{if(interval){clearInterval(interval);interval=null;start.textContent='Resume'}else{start.textContent='Pause';interval=setInterval(()=>{remaining--;draw();if(remaining<=0){clearInterval(interval);interval=null;start.textContent='Start';sfx.chime();alert('Focus session complete!')}},1000)}};
    body.querySelector('#freset').onclick=reset;reset();
  },{emoji:'🍅'});
}
function openSystemMonitor(){
  openWin('System Monitor',500,380,body=>{
    const panel=el('div','set');body.appendChild(panel);
    function draw(){
      panel.innerHTML=`<h2>System Monitor</h2><p><b>Browser OS:</b> 2.5.0</p><p><b>Profile:</b> ${esc(S.profileName||'User')}</p><p><b>Device:</b> ${esc(S.deviceName||'BROWSER-OS')}</p><p><b>Platform:</b> ${esc(navigator.platform||'Browser')}</p><p><b>Screen:</b> ${screen.width} × ${screen.height}</p><p><b>Open windows:</b> ${Object.keys(wins).length}</p><p><b>Saved files:</b> ${countFiles(S.fs)}</p><p><b>To-do items:</b> ${(S.todo||[]).length}</p><button class="btn alt" id="smrefresh">Refresh</button>`;
      panel.querySelector('#smrefresh').onclick=draw;
    }
    draw();
  },{emoji:'📈'});
}
function countFiles(dir){let n=0;(dir.kids||[]).forEach(k=>{if(k.type==='dir')n+=countFiles(k);else n++});return n}
function openSystemInfo(){
  openWin('System Information',520,390,body=>{
    body.innerHTML=`<div class="settings-page"><h2>About this device</h2><p><b>${esc(S.deviceName||'BROWSER-OS')}</b></p><p>Browser OS version 2.5.0</p><p>Platform: ${esc(navigator.platform||'Browser')}</p><p>Browser: ${esc(navigator.userAgent)}</p><p>Storage: Chrome extension local storage</p><p>This is a browser-based desktop simulation, not a replacement for Windows or a native operating system.</p></div>`;
  },{emoji:'ℹ️'});
}
function openDownloads(){
  openWin('Downloads',480,300,body=>{
    body.innerHTML='<div class="set"><h3>Downloads</h3><p>Files you download from apps are saved by your browser. Imported files are available in File Explorer for this session.</p><button class="btn" id="openfiles">Open File Explorer</button></div>';
    body.querySelector('#openfiles').onclick=openFiles;
  },{emoji:'⬇️'});
}

load(boot);
})();